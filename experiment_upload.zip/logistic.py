#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 27 10:54:40 2022

@author: shnoh92
"""

import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import confusion_matrix
from sklearn.metrics import roc_curve, roc_auc_score

train_corp_data = np.loadtxt("train_corp.txt", delimiter="\t")
test_corp_data = np.loadtxt("test_corp.txt", delimiter="\t")

train_corp_label_data = np.loadtxt("train_corp_label(LR).txt", delimiter="\t")
test_corp_label_data = np.loadtxt("test_corp_label(LR).txt", delimiter="\t")

train_corp_dataset = np.nan_to_num(np.asarray(train_corp_data, dtype=np.int))
train_corp_label_dataset = np.nan_to_num(np.asarray(train_corp_label_data, dtype=np.int))
test_corp_dataset = np.nan_to_num(np.asarray(test_corp_data, dtype=np.int))
test_corp_label_dataset = np.nan_to_num(np.asarray(test_corp_label_data, dtype=np.int))

train_input_corp_tensor = torch.from_numpy(train_corp_dataset).float()
train_input_corp_label_tensor = torch.from_numpy(train_corp_label_dataset).float()

num_col = train_input_corp_tensor.size(1)
channel_mean = [torch.mean(train_input_corp_tensor[:,i]) for i in range(num_col)]
channel_std = [torch.std(train_input_corp_tensor[:,i]) for i in range(num_col)]
for i in range(num_col):
	train_input_corp_tensor[:,i]=(train_input_corp_tensor[:,i]-channel_mean[i])/channel_std[i]

inp = []
label = []
train_lstm_inp = []
train_lstm_label = []
train_corp_id = []
for j in range(int(train_input_corp_tensor.size(0))):
	inp = train_input_corp_tensor[j]
	label = train_input_corp_label_tensor[j]
	for k in range(9):
		train_lstm_inp.append(inp[13*k:13*(k+1)])
		train_lstm_label.append(label[k])
		train_corp_id.append(j)

test_input_corp_tensor = torch.from_numpy(test_corp_dataset).float()
test_input_corp_label_tensor = torch.from_numpy(test_corp_label_dataset).float()

num_col = test_input_corp_tensor.size(1)
channel_mean = [torch.mean(test_input_corp_tensor[:,i]) for i in range(num_col)]
channel_std = [torch.std(test_input_corp_tensor[:,i]) for i in range(num_col)]
for i in range(num_col):
	test_input_corp_tensor[:,i]=(test_input_corp_tensor[:,i]-channel_mean[i])/channel_std[i]

inp = []
label = []
test_lstm_inp = []
test_lstm_label = []
test_corp_id = []
for j in range(int(test_input_corp_tensor.size(0))):
	inp = test_input_corp_tensor[j]
	label = test_input_corp_label_tensor[j]
	for k in range(9):
		test_lstm_inp.append(inp[13*k:13*(k+1)])
		test_lstm_label.append(label[k])
		test_corp_id.append(j)


model1 = LogisticRegression()
model2 = KNeighborsClassifier()
model3 = DecisionTreeClassifier()
model4 = RandomForestClassifier()

train_lstm_inp = [t.numpy() for t in train_lstm_inp]
train_lstm_label = [t.numpy() for t in train_lstm_label]
test_lstm_inp = [t.numpy() for t in test_lstm_inp]
test_lstm_label = [t.numpy() for t in test_lstm_label]

model1.fit(train_lstm_inp, train_lstm_label)
model2.fit(train_lstm_inp, train_lstm_label)
model3.fit(train_lstm_inp, train_lstm_label)
model4.fit(train_lstm_inp, train_lstm_label)

y1_train_pred = cross_val_predict(model1, train_lstm_inp, train_lstm_label)
y2_train_pred = cross_val_predict(model2, train_lstm_inp, train_lstm_label)
y3_train_pred = cross_val_predict(model3, train_lstm_inp, train_lstm_label)
y4_train_pred = cross_val_predict(model4, train_lstm_inp, train_lstm_label)

print(confusion_matrix(train_lstm_label, y1_train_pred))
print(confusion_matrix(train_lstm_label, y2_train_pred))
print(confusion_matrix(train_lstm_label, y3_train_pred))
print(confusion_matrix(train_lstm_label, y4_train_pred))

print(model1.score(train_lstm_inp, train_lstm_label))
print(model1.score(test_lstm_inp, test_lstm_label))

print(model1.coef_)

print(model2.score(train_lstm_inp, train_lstm_label))
print(model2.score(test_lstm_inp, test_lstm_label))


print(model3.score(train_lstm_inp, train_lstm_label))
print(model3.score(test_lstm_inp, test_lstm_label))


print(model4.score(train_lstm_inp, train_lstm_label))
print(model4.score(test_lstm_inp, test_lstm_label))

##AUC of the ROC

y1_pred_proba = model1.predict_proba(test_lstm_inp)[::,1]
y2_pred_proba = model2.predict_proba(test_lstm_inp)[::,1]
y3_pred_proba = model3.predict_proba(test_lstm_inp)[::,1]
y4_pred_proba = model4.predict_proba(test_lstm_inp)[::,1]

fpr1, tpr1, __ = roc_curve(test_lstm_label, y1_pred_proba)
fpr2, tpr2, __ = roc_curve(test_lstm_label, y2_pred_proba)
fpr3, tpr3, __ = roc_curve(test_lstm_label, y3_pred_proba)
fpr4, tpr4, __ = roc_curve(test_lstm_label, y4_pred_proba)

print(roc_auc_score(test_lstm_label, y1_pred_proba))
print(roc_auc_score(test_lstm_label, y2_pred_proba))
print(roc_auc_score(test_lstm_label, y3_pred_proba))
print(roc_auc_score(test_lstm_label, y4_pred_proba))

plt.plot([0,1],[0,1],color = "navy")
plt.plot(fpr1, tpr1, color = "darkorange", label='LogisticRegression')
plt.plot(fpr2, tpr2, color = "deeppink", label='KNeighbors')
plt.plot(fpr3, tpr3, color = "grey", label='DecisionTree')
plt.plot(fpr4, tpr4, color = "red", label='RandomForest')
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.legend(loc='lower right')
plt.show()























