# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import confusion_matrix
from sklearn.metrics import roc_curve, roc_auc_score

train_corp_data = np.loadtxt("train_corp.txt", delimiter="\t")
test_corp_data = np.loadtxt("test_corp.txt", delimiter="\t")

train_corp_label_data = np.loadtxt("train_corp_label(LR).txt", delimiter="\t")
test_corp_label_data = np.loadtxt("test_corp_label(LR).txt", delimiter="\t")

train_corp_dataset = np.nan_to_num(np.asarray(train_corp_data, dtype=np.int))
train_corp_label_dataset = np.nan_to_num(np.asarray(train_corp_label_data, dtype=np.int))
test_corp_dataset = np.nan_to_num(np.asarray(test_corp_data, dtype=np.int))
test_corp_label_dataset = np.nan_to_num(np.asarray(test_corp_label_data, dtype=np.int))

train_input_corp_tensor = torch.from_numpy(train_corp_dataset).float()
train_input_corp_label_tensor = torch.from_numpy(train_corp_label_dataset).float()

num_col = train_input_corp_tensor.size(1)
