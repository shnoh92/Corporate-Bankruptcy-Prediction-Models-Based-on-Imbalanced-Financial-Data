# -*- coding: utf-8 -*-
"""
Created on Wed Feb  2 05:07:05 2022

@author: shnoh
"""


import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt

train_corp_data = np.loadtxt("train_corp.txt", delimiter="\t")
test_corp_data = np.loadtxt("test_corp.txt", delimiter="\t")

train_corp_label_data = np.loadtxt("train_corp_label.txt", delimiter="\t")
test_corp_label_data = np.loadtxt("test_corp_label.txt", delimiter="\t")
#dataset = np.nan_to_num(np.asarray(data, dtype=np.int))
#input_tensor = torch.from_numpy(dataset).float()


#print(input_tensor)
#print(input_tensor.size(1))
sequence_length=4
latency=0


class CustomDataset(Dataset):
    def __init__(self, corp_data, corp_label_data, sequence_length=4, latency=0):
        super(CustomDataset, self).__init__()
        corp_dataset = np.nan_to_num(np.asarray(corp_data, dtype=np.int))
        corp_label_dataset = np.nan_to_num(np.asarray(corp_label_data, dtype=np.int))
        self.sqlen = sequence_length
        self.input_corp_tensor = torch.from_numpy(corp_dataset).float()
        self.input_corp_label_tensor = torch.from_numpy(corp_label_dataset).float()
        num_col = self.input_corp_tensor.size(1)
        self.channel_mean = [torch.mean(self.input_corp_tensor[:,i]) for i in range(num_col)]
        self.channel_std = [torch.std(self.input_corp_tensor[:,i]) for i in range(num_col)]
        for i in range(num_col):
            self.input_corp_tensor[:,i]=(self.input_corp_tensor[:,i]-self.channel_mean[i])/self.channel_std[i]
        self.inp = []
        self.label = []
        self.imsi1_inp = []
        self.imsi2_inp = []
        self.imsi3_inp = []
        self.imsi4_inp = []
        self.imsi5_inp = []
        self.imsi_inp = []
        self.imsi_label = []
        self.lstm_inp = []
        self.lstm_label = []
        self.corp_id = []
        for j in range(int(self.input_corp_tensor.size(0))):
            self.inp = self.input_corp_tensor[j]
            self.label = self.input_corp_label_tensor[j]
            self.imsi_inp = []
            for k in range(9):
                self.imsi_inp.append(self.inp[13*k:13*(k+1)])
            for i in range(6):
                self.imsi1_inp = self.imsi_inp[i]
                self.imsi2_inp = self.imsi_inp[i+1]
                self.imsi3_inp = self.imsi_inp[i+2]
                self.imsi4_inp =self.imsi_inp[i+3]
                self.imsi5_inp=torch.stack((self.imsi1_inp,self.imsi2_inp,self.imsi3_inp,self.imsi4_inp),0)
                self.lstm_inp.append(self.imsi5_inp)
                self.lstm_label.append(self.label[i])
                self.corp_id.append(j)

    def __len__(self):
        return len(self.lstm_label)
    def __getitem__(self, idx):
        return self.lstm_inp[idx], self.lstm_label[idx], self.corp_id[idx]




#inp, label = [], []
#for i in range(input_tensor.size(1)-sequence_length-latency):
#    inp.append(input_tensor[:,i:i+sequence_length])
#    label.append(input_tensor[:,i+sequence_length:i+sequence_length+latency])

#print(inp)
#print(label)

# experiment configuration
epochs = 50
batch_size = 1
# model configuration
hidden_size = 256

train_dataset = CustomDataset(train_corp_data, train_corp_label_data, sequence_length=sequence_length, latency=latency)
test_dataset = CustomDataset(test_corp_data, test_corp_label_data, sequence_length=sequence_length, latency=latency)
train_dataloader = DataLoader(train_dataset, batch_size=batch_size, num_workers=0,
                            pin_memory=True,drop_last=True)
test_dataloader = DataLoader(test_dataset, batch_size=batch_size, num_workers=0,
                            pin_memory=True,drop_last=True)

# Define the model
class LSTM(nn.Module):
    def __init__(self, input_size, hidden_size, device):
        super(LSTM, self).__init__()
        self.hidden_size = hidden_size
        self.device = device

        self.inp = nn.Linear(input_size, hidden_size).to(device)
        self.LSTMCell = nn.LSTMCell(hidden_size, hidden_size).to(device)
        self.dropout = nn.Dropout(p=0.05).to(device)
        self.fc = nn.Linear(hidden_size, 1).to(device)
        self.fc1 = nn.Linear(hidden_size, 13).to(device)

    def step(self, inp, hidden=None):
        # dropout은 현재 time step에만 적용
        hidden = self.LSTMCell(self.dropout(inp))

        return hidden

    def forward(self, inputs, hidden=None, steps=0):
        if steps == 0:
            steps = inputs.size(1)

        inputs = self.inp(inputs)

        hidden = None
        for i in range(steps):
            hidden = self.step(inputs[:,i], hidden)
            coeff = self.fc1(hidden[0])

        hidden[0].mean().backward(retain_graph=True)

        out = self.dropout(self.dropout(hidden[0]))
        out = self.fc(out)

        return out, coeff

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

lstm = LSTM(input_size=13,
                hidden_size=hidden_size,
                device=device)

criterion = nn.MSELoss()
optimizer = torch.optim.SGD(lstm.parameters(), lr=1e-5)


train_results_out, test_results_out, results_loss = [], [], []
for e in range(epochs):
    loss_avg = 0
    correct = 0
    total = 0
    tn = 0
    fp = 0
    fn = 0
    tp = 0
    coeff_sum = 0
    codff_avg = 0
    for i, batch in enumerate(train_dataloader, 1):
        optimizer.zero_grad()
        inp, label, corp_id = batch
        inp, label, corp_id = inp.to(device), label.to(device), corp_id.to(device)
        out, coeff = lstm(inp)
        train_results_out.append((e, i, corp_id, out))
        loss = criterion(out, label)
        loss.backward()
        loss_avg += loss.item()
        optimizer.step()
        total += label.size(0)
        coeff_sum += coeff
        if ((label==1)and(out>0.5)):
            tn += 1
        elif ((label==1)and(out<0.5)):
            fp += 1
        elif ((label==0)and(out>0.5)):
            fn += 1
        elif ((label==0)and(out<0.5)):
            tp += 1
        if (abs(out-label)<0.5):
            correct += 1
    coeff_avg = coeff_sum/total
    acc = 100.*correct/total
    if((tp+fp)>0): normal_precision = tp/(tp+fp)
    else: normal_precision = 0
    if((tp+fn)>0): normal_recall = tp/(tp+fn)
    else: normal_recall = 0
    if((tn+fn)>0): default_precision = tn/(tn+fn)
    else: default_precision = 0
    if((fp+tn)>0): default_recall = tn/(fp+tn)
    else: default_recall = 0
    print("epoch: {} | acc: {} | normal_prec: {} | normal_recall: {}".format(e, acc, normal_precision, normal_recall))
    print("epoch: {} | acc: {} | default_prec: {} | default_recall: {}".format(e, acc, default_precision, default_recall))
#    print("epoch: {} | tn: {} | fp: {} | fn: {} | tp: {}".format(tn, fp, fn, tp))
loss_avg = 0
correct = 0
total = 0
tn = 0
fp = 0
fn = 0
tp = 0
for i, batch in enumerate(test_dataloader, 1):

    inp, label, corp_id = batch
    inp, label, corp_id = inp.to(device), label.to(device), corp_id.to(device)
    out, coeff = lstm(inp)
    test_results_out.append((i, corp_id, out))
    loss = criterion(out, label)

    loss_avg += loss.item()

    total += label.size(0)
    if ((label==1)and(out>0.5)):
        tn += 1
    elif ((label==1)and(out<0.5)):
        fp += 1
    elif ((label==0)and(out>0.5)):
        fn += 1
    elif ((label==0)and(out<0.5)):
        tp += 1
    if (abs(out-label)<0.5):
        correct += 1
acc = 100.*correct/total
if((tp+fp)>0):
	normal_precision = tp/(tp+fp)
else: normal_precision = 0
if((tp+fn)>0):
	normal_recall = tp/(tp+fn)
else: normal_recall = 0
if((tn+fn)>0):
	default_precision = tn/(tn+fn)
else: default_precision = 0
if((fp+tn)>0):
	default_recall = tn/(fp+tn)
else: default_recall = 0
print("epoch: {} | acc: {} | normal_prec: {} | normal_recall: {}".format(e, acc, normal_precision, normal_recall))
print("epoch: {} | acc: {} | default_prec: {} | default_recall: {}".format(e, acc, default_precision, default_recall))
print("epoch: {} | tn: {} | fp: {} | fn: {} | tp: {}".format(tn, fp, fn, tp))













